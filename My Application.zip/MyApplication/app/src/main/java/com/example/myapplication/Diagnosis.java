package com.example.myapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Diagnosis extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diagnosis);

        if(getIntent().hasExtra("com.example.myapplication.DIAGNOSIS"))
        {
            //TextView diagnosisOut = (TextView) findViewById(R.id.textView2);
            //String diagnosisIn = getIntent().getExtras().getString("com.example.myapplication.DIAGNOSIS");
            //diagnosisOut.setText(diagnosisIn);
        }
    }
}