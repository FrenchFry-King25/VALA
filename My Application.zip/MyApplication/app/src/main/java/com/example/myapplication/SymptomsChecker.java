package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SymptomsChecker extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms_checker);

        Button submitBtn = findViewById(R.id.button4);
        submitBtn.setOnClickListener(v -> {
            CheckBox throatBox = findViewById(R.id.throatBox);
            Boolean throat = throatBox.isChecked();
            CheckBox noseBox = findViewById(R.id.noseBox);
            Boolean nose = noseBox.isChecked();
            CheckBox eyeBox = findViewById(R.id.eyeBox);
            Boolean eye = eyeBox.isChecked();
            CheckBox sneezeBox = findViewById(R.id.sneezeBox);
            Boolean sneeze = sneezeBox.isChecked();
            CheckBox skinBox = findViewById(R.id.skinBox);
            Boolean skin = skinBox.isChecked();
            CheckBox fatigueBox = findViewById(R.id.fatigueBox);
            Boolean fatigue = fatigueBox.isChecked();
            CheckBox breatheBox = findViewById(R.id.breatheBox);
            Boolean breathe = breatheBox.isChecked();
            CheckBox coughBox = findViewById(R.id.coughBox);
            Boolean cough = coughBox.isChecked();
            CheckBox gastrointestinalBox = findViewById(R.id.gastrointestinalBox);
            Boolean gastrointestinal = gastrointestinalBox.isChecked();
            CheckBox headacheBox = findViewById(R.id.headacheBox);
            Boolean headache = headacheBox.isChecked();
            CheckBox checkBox33 = findViewById(R.id.checkBox33);
            Boolean lymph_tonsils = checkBox33.isChecked();
            CheckBox feverBox = findViewById(R.id.feverBox);
            Boolean fever = feverBox.isChecked();
            CheckBox faintBox = findViewById(R.id.faintBox);
            Boolean faint = faintBox.isChecked();

            EditText stomach = findViewById(R.id.stomachIn);
            int stomachPain = Integer.parseInt(stomach.getText().toString());
            if(stomachPain > 10){stomachPain = 10;}
            else if (stomachPain < 0){stomachPain = 0;}
            EditText chest = findViewById(R.id.chestIn);
            int chestPain = Integer.parseInt(chest.getText().toString());
            if(chestPain > 10){chestPain = 10;}
            else if (chestPain < 0){chestPain = 0;}

            //use the variables above^^ to make the "diagnosis" string correct
            String diagnosis = "Asthma";

            Intent next = new Intent(getApplicationContext(), Diagnosis.class);
            next.putExtra("com.example.myapplication.DIAGNOSIS", diagnosis);
            startActivity(next);
        });
    }
}